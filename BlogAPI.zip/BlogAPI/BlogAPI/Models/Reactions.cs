﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Reactions
    {
        [Key]
        public int id { get; set; }

        [Required][ForeignKey("ReactionTypes")]
        public int type_id { get; set; }

        [Required][ForeignKey("Users")]
        public int user_id { get; set; }

        [Required][ForeignKey("Posts")]
        public int post_id { get; set; }

        [Required]
        public DateTime created_on { get; set; }

        [Required]
        public DateTime updated_on { get; set; }

        private Reactions()
        {

        }

        public Reactions(DateTime created_on, DateTime updated_on)
        {
            this.updated_on = updated_on;
            this.created_on = created_on;
        }
    }
}

