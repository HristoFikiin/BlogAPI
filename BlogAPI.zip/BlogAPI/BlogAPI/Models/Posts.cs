﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Posts
    {
        [Key]
        public int id { get; set; }

        [Required]
        public string title { get; set; }

        [Required]
        public string content { get; set; }

        [Required][ForeignKey("Users")] 
        public string user_id { get; set; }

        [Required]
        public DateTime created_on { get; set; }

        [Required]
        public DateTime updated_on { get; set; }

        [Required]
        public string is_visible { get; set; }

        private Posts()
        {

        }

        public Posts(string title, string content, string is_visible, DateTime created_on, DateTime updated_on)
        {
            this.is_visible = is_visible;
            this.created_on = created_on;
            this.updated_on = updated_on;
            this.title = title;
            this.content = content;
        }
    }
}

