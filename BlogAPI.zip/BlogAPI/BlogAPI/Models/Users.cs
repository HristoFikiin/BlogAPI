﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Users
    {
        [Key]
        public int id { get; set; }

        [Required]
        public string username { get; set; }

        [Required]
        public string password_hash { get; set; }

        [Required]
        public string role { get; set; }

        private Users()
        {

        }

        public Users(string username, string password_hash, string role)
        {
            this.username = username;
            this.password_hash = password_hash;
            this.role = role;
        }
    }
}

