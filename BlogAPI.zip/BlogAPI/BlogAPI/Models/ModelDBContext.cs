﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace Model
{
    public class ModelDBContext : DbContext
    {
        public ModelDBContext() : base()
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=localhost/SQLEXPRESS;Database=BlogAPIdb;Trusted_Connection=True;");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

        }

        public DbSet<Comments> Comments { get; set; }

        public DbSet<Posts> Posts { get; set; }

        public DbSet<Reactions> Reactions { get; set; }

        public DbSet<ReactionTypes> ReactionTypes { get; set; }

        public DbSet<Users> Users { get; set; }

        public DbSet<UsersToFollow> UsersToFollow { get; set; }

    }

}
