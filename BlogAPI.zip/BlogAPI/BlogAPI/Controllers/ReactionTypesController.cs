﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Controller
{
    [ApiController]
    [Route("[controller]")]
    class ReactionTypesController : IDB<ReactionTypes, int>
    {
        private ModelDBContext _context;

        public ReactionTypesController(ModelDBContext context)
        {
            this._context = context;
        }

        [HttpGet]
        public void Create(ReactionTypes item)
        {
            try
            {
                _context.ReactionTypes.Add(item);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public void Delete(int key)
        {
            try
            {
                ReactionTypes ReactionTypesFromDb = Read(key);

                _context.Remove(ReactionTypesFromDb);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public ReactionTypes Read(int key)
        {
            try
            {
                return _context.ReactionTypes.Find(key);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public IEnumerable<ReactionTypes> ReadAll()
        {
            try
            {
                return _context.ReactionTypes.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public void Update(ReactionTypes item)
        {
            try
            {
                ReactionTypes ReactionTypesFromDB = Read(item.id);

                _context.Entry(ReactionTypesFromDB).CurrentValues.SetValues(item);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


    }
}
