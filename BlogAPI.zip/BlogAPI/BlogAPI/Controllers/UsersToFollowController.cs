﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Controller
{
    [ApiController]
    [Route("[controller]")]
    class UsersToFollowController : IDB<UsersToFollow, int>
    {
        private ModelDBContext _context;

        public UsersToFollowController(ModelDBContext context)
        {
            this._context = context;
        }

        [HttpGet]
        public void Create(UsersToFollow item)
        {
            try
            {
                _context.UsersToFollow.Add(item);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public void Delete(int key)
        {
            try
            {
                UsersToFollow UsersToFollowFromDb = Read(key);

                _context.Remove(UsersToFollowFromDb);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public UsersToFollow Read(int key)
        {
            try
            {
                return _context.UsersToFollow.Find(key);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public IEnumerable<UsersToFollow> ReadAll()
        {
            try
            {
                return _context.UsersToFollow.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public void Update(UsersToFollow item)
        {
            try
            {
                UsersToFollow UsersToFollowFromDB = Read(item.follow_user_id);

                _context.Entry(UsersToFollowFromDB).CurrentValues.SetValues(item);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


    }
}
