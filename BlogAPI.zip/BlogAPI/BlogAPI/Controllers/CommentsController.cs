﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Controller
{
    [ApiController]
    [Route("[controller]")]
    class CommentsController : IDB<Comments, int>
    {
        private ModelDBContext _context;

        public CommentsController(ModelDBContext context)
        {
            this._context = context;
        }

        [HttpGet]
        public void Create(Comments item)
        {
            try
            {
                _context.Comments.Add(item);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public void Delete(int key)
        {
            try
            {
                Comments CommentsFromDb = Read(key);

                _context.Remove(CommentsFromDb);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public Comments Read(int key)
        {
            try
            {
                return _context.Comments.Find(key);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public IEnumerable<Comments> ReadAll()
        {
            try
            {
                return _context.Comments.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public void Update(Comments item)
        {
            try
            {
                Comments CommentsFromDB = Read(item.id);

                _context.Entry(CommentsFromDB).CurrentValues.SetValues(item);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


    }
}
