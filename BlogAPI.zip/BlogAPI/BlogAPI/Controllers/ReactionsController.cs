﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Controller
{
    [ApiController]
    [Route("[controller]")]
    class ReactionsController : IDB<Reactions, int>
    {
        private ModelDBContext _context;

        public ReactionsController(ModelDBContext context)
        {
            this._context = context;
        }

        [HttpGet]
        public void Create(Reactions item)
        {
            try
            {
                _context.Reactions.Add(item);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public void Delete(int key)
        {
            try
            {
                Reactions ReactionsFromDb = Read(key);

                _context.Remove(ReactionsFromDb);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public Reactions Read(int key)
        {
            try
            {
                return _context.Reactions.Find(key);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public IEnumerable<Reactions> ReadAll()
        {
            try
            {
                return _context.Reactions.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public void Update(Reactions item)
        {
            try
            {
                Reactions ReactionsFromDB = Read(item.id);

                _context.Entry(ReactionsFromDB).CurrentValues.SetValues(item);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


    }
}
