﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Controller
{
    [ApiController]
    [Route("[controller]")]
    class UsersController : IDB<Users, int>
    {
        private ModelDBContext _context;

        public UsersController(ModelDBContext context)
        {
            this._context = context;
        }

        [HttpGet]
        public void Create(Users item)
        {
            try
            {
                _context.Users.Add(item);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public void Delete(int key)
        {
            try
            {
                Users UsersFromDb = Read(key);

                _context.Remove(UsersFromDb);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public Users Read(int key)
        {
            try
            {
                return _context.Users.Find(key);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public IEnumerable<Users> ReadAll()
        {
            try
            {
                return _context.Users.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        public void Update(Users item)
        {
            try
            {
                Users UsersFromDB = Read(item.id);

                _context.Entry(UsersFromDB).CurrentValues.SetValues(item);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


    }
}
