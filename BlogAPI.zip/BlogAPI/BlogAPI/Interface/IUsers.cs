﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlogAPI.Interface
{
    public interface IUsers
    {
        public List<Users> GetUserDetails();
        public Users GetUserDetails(int id);
        public void AddUser(Users user);
        public void UpdateUser(Users user);
        public Users DeleteUser(int id);
        public bool CheckUser(int id);
    }
}
